// 这里只是为了方便才直接把变量挂在window下， 实际工作中请一定避免这样的做法
var games = [
    {
        "id"       : 0,
        "name"     : "神秘海域123",
        "img"      : "../static/images/uncharted-collection.jpg",
        "price"    : 160.80,
        "purchased": false
    },
    {
        "id"       : 1,
        "name"     : "神秘海域4",
        "img"      : "../static/images/uncharted4.jpg",
        "price"    : 318.40,
        "purchased": false
    },
    {
        "id"       : 2,
        "name"     : "合金装备 幻痛",
        "img"      : "../static/images/metal-gear-solid.jpg",
        "price"    : 179.00,
        "purchased": false
    },
    {
        "id"       : 3,
        "name"     : "刺客信条 枭雄",
        "img"      : "../static/images/assassin.jpg",
        "price"    : 118.80,
        "purchased": false
    },
    {
        "id"       : 4,
        "name"     : "如龙 零",
        "img"      : "../static/images/dragon-0.jpg",
        "price"    : 377.00,
        "purchased": false
    },
    {
        "id"       : 5,
        "name"     : "如龙 极",
        "img"      : "../static/images/dragon-kiwami.jpg",
        "price"    : 340.20,
        "purchased": false
    },
    {
        "id"       : 6,
        "name"     : "如龙 6",
        "img"      : "../static/images/dragon-6.jpg",
        "price"    : 468.00,
        "purchased": false
    },
    {
        "id"       : 7,
        "name"     : "GTA5",
        "img"      : "../static/images/gta5.jpg",
        "price"    : 234.00,
        "purchased": false
    },
    {
        "id"       : 8,
        "name"     : "看门狗",
        "img"      : "../static/images/watch-dogs.jpg",
        "price"    : 69.30,
        "purchased": false
    },
    {
        "id"       : 9,
        "name"     : "看门狗2",
        "img"      : "../static/images/watch-dogs2.jpg",
        "price"    : 420.00,
        "purchased": false
    },
    {
        "id"       : 10,
        "name"     : "四海兄弟 III",
        "img"      : "../static/images/mafia.jpg",
        "price"    : 327.60,
        "purchased": false
    },
    {
        "id"       : 11,
        "name"     : "热血无赖",
        "img"      : "../static/images/sleeping-dogs.jpg",
        "price"    : 198,
        "purchased": false
    }
]
